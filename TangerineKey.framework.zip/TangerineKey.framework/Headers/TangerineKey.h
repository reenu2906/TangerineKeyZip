//
//  TangerineKey.h
//  TangerineKey
//
//  Created by MAC PRO on 05/03/20.
//  Copyright © 2020 MAC PRO. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TangerineKey.
FOUNDATION_EXPORT double TangerineKeyVersionNumber;

//! Project version string for TangerineKey.
FOUNDATION_EXPORT const unsigned char TangerineKeyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TangerineKey/PublicHeader.h>


